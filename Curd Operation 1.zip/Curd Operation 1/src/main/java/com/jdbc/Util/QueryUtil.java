package com.jdbc.Util;

public class QueryUtil {
	
	public static String insertEmployeeQuery() {
		return"INSERT INTO EMPLOYEE_INFO1(EMPLOYEE_NAME, EMPLOYEE_ADDRESS, EMPLOYEE_SALARY) VALUES(?,?,?)";
	}
	
	public static String selectAllEmployeeQuery() {
		return "SELECT * FROM EMPLOYEE_INFO1";
	}
	
	public static String selectEmployeeById(int employeeId) {
		return "SELECT * FROM EMPLOYEE_INFO1 WHERE EMPLOYEE_ID = " +employeeId;
	}
	
	public static String deleteEmployeeById(int employeeId) {
	 return "DELETE FROM EMPLOYEE_INFO1 WHERE EMPLOYEE_ID = " +employeeId;
	}

	public static String updateEmployeeQuery(int employeeId) {
		return "UPDATE EMPLOYEE_INFO1 SET EMPLOYEE_NAME = ?, EMPLOYEE_ADDRESS = ?, EMPLOYEE_SALARY = ? WHERE EMPLOYEE_ID = " 
	+employeeId;
	}
}
