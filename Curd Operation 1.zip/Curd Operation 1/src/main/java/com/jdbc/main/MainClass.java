package com.jdbc.main;

import java.util.Scanner;

import com.jdbc.model.Employee;
import com.jdbc.service.databaseservice;

public class MainClass {

	public static void main(String[] args) {
		
		databaseservice Databaseservice = new databaseservice();
		
		try(Scanner s = new Scanner(System.in);){
			
			boolean isRunning=true;
			while(true) {
		// TODO Auto-generated method stub
          System.out.println("Enter choice");
          System.out.println("1. Insert");
          System.out.println("2. Select all");
          System.out.println("3. Select employee by an id");
          System.out.println("4. Delete employee");
          System.out.println("5. Update employee");
          System.out.println("6. Exit"); 
         
          int choice= Integer.parseInt(s.nextLine());
          switch (choice) {
		case 1: 
			System.out.println("Enter name,address, salary");
			
			Databaseservice.insertEmployee(new Employee(s.nextLine(),s.nextLine(),Double.parseDouble(s.nextLine())));
			break;
			
        case 2: 
        	Databaseservice.getAllEmployee();
			break;
			
        case 3: 
        	System.out.println("Enter id of an employee");
        	Databaseservice.getEmployeeById(Integer.parseInt(s.nextLine()));
	       break;
	       
        case 4: 
        	System.out.println("Enter id of an employee");
        	Databaseservice.deleteEmployeeById(Integer.parseInt(s.nextLine()));
	
	      break;
	      
         case 5: 
        	 System.out.println("Enter id of an employee");
        	 int updateId = Integer.parseInt(s.nextLine());
        	 boolean isFound = Databaseservice.getEmployeeById(updateId);
        	 if(isFound) {
        		 System.out.println("Enter name, address, salary");
        		 Employee employee = new Employee(updateId, s.nextLine(), s.nextLine(), Double.parseDouble(s.nextLine()));
        		 Databaseservice.updateEmployee(employee);
        	 }
	        break;
	        
         case 6:
        	 System.out.println("thank you...Visit Again");
        	 isRunning=false;
        	 break;
	        
	        default :
	        	System.out.println("Incorrect choice");
	        	break;
			
			
			
			
			
		
          }
		}
	}catch (Exception e) {
		//TODO: handle exception
		throw new RuntimeException("Something went wrong "+e);
	}

}
}
