package com.user;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.DriverManager;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.servlet.annotation.MultipartConfig;

import java.sql.*;
/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
@MultipartConfig
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	@SuppressWarnings("deprecation")
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		try(PrintWriter out = response.getWriter()){
			
			
			  
			   //getting all the incoming detail from the request..
			   String name=request.getParameter("user_name");
			   String password=request.getParameter("user_password");
			   String email=request.getParameter("user_email");
			  Part part= request.getPart("image");
			  
			  String filename=part.getSubmittedFileName();
            //   out.println(filename);			   
			  
			   try {
				   
				   Thread.sleep(3000);
				  Class.forName("com.mysql.jdbc.Driver");
				   
				   Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mayurd","root","root");
				   
				 String q="insert into user  (name,password,email,imageName) values(?,?,?,?)";
				   
				 PreparedStatement pstmt=con.prepareStatement(q);
				   
				  pstmt.setString(1,name);
				 pstmt.setString(2,password);
				  pstmt.setString(3,email);
				   pstmt.setString(4, filename);
				pstmt.executeUpdate();
				
				InputStream is= part.getInputStream();
				byte [] data=new byte [is.available()];
				
				is.read(data);
				 String path=request.getRealPath("/")+"img"+File.separator+filename;
				// out.println(path);
			FileOutputStream fos=new FileOutputStream(path);
			fos.write(data);
			fos.close();
				   
				   out.println("Done");
				   
			   }catch (Exception e) {
				   e.printStackTrace();
				   
				   out.println("Error");
			   }
			   
			
		}
		
	}

	
	//protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	doGet(request, response);
//	}

}
